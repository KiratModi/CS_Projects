"""
a)	There are many fruitful functions I could think of like calculating cart total or estimating delivery time but I think most valuable function will be recommend a product that customer wants for which program will
1.	Gather information of product that user viewed then add in in a container then program will try to find details which match the details in the container. Which ever matches best will be add to recommend container
2.	For loops and If satements could work here and I am submitting a code which should recommend as need.

"""


def recommend_products(user_actions, product_catalog):
    # user_actions is a list of product IDs that the user has viewed
    # product_catalog is a dictionary where keys are product IDs and values are product details, including category
    
    recommendations = [] #container
    viewed_categories = set() 
    
    # Collect categories of viewed products
    for product_id in user_actions:
        if product_id in product_catalog:
            viewed_categories.add(product_catalog[product_id]['category'])
    
    # Recommend products from the same categories
    for product_id, details in product_catalog.items():
        if details['category'] in viewed_categories and product_id not in user_actions:
            recommendations.append(product_id) #not sure of this part if it will work or not
    
    return recommendations

"""
Example usage as per me:
 user_actions = ['p1', 'p2']
 product_catalog = {
     'p1': {'name': 'Laptop', 'category': 'Electronics'},
     'p2': {'name': 'Headphones', 'category': 'Electronics'},
     'p3': {'name': 'Shoes', 'category': 'Fashion'},
     'p4': {'name': 'Camera', 'category': 'Electronics'},
     'p5': {'name': 'T-Shirt', 'category': 'Fashion'}
 }
 recommendations = recommend_products(user_actions, product_catalog)
 print(recommendations)  # Should output products from the 'Electronics' category that the user has not viewed yet, e.g., ['p4']
 """

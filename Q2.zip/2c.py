"""
Q2.c

recursive function to extract the integer value of a binary string

function binary_to_int(binary_str):
    if binary_str is empty:
        return 0
    last_char = last character of binary_str
    remaining_str = binary_str without the last character
    return int(last_char) + 2 * binary_to_int(remaining_str)

"""

def binary_to_int(binary_str):
    # Base case: If the string is empty, return 0
    if binary_str == "":
        return 0
    
    # Recursive case:
    # Extract the last character
    last_char = binary_str[-1]
    
    # Remove the last character from the string
    remaining_str = binary_str[:-1]
    
    # Convert last_char to its integer value and compute the result
    return int(last_char) + 2 * binary_to_int(remaining_str)

"""print(binary_to_int("101")) # Expected output: 5
Example usage (commented out to prevent execution in PCI)
print(binary_to_int("11")) # Expected output: 3"""

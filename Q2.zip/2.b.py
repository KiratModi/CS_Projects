"""
Q2-b
This will update users orders

Function update_order(order, item_name, new_quantity, item_price=None)
    If item_name exists in order
        If new_quantity == 0
            Remove item_name from order
            Print "Removed {item_name} from the order."
        Else
            Update order[item_name]['quantity'] to new_quantity
            Print "Updated {item_name} to {new_quantity} units."
    Else
        If new_quantity > 0 AND item_price is not None
            Add item_name to order with 'quantity' = new_quantity and 'price' = item_price
            Print "Added {item_name} to the order with {new_quantity} units."
        Else
            Print "Cannot add {item_name} to the order without a valid price and quantity."
    End If
    Return order
End Function

"""

def update_order(order, item_name, new_quantity, item_price=None):
    if item_name in order:
        if new_quantity == 0:
            del order[item_name]
            print(f"Removed {item_name} from the order.")  #Removing items when 0
        else:
            order[item_name]['quantity'] = new_quantity
            print(f"Updated {item_name} to {new_quantity} units.")
    else:
        if new_quantity > 0 and item_price is not None: # Checking if item price is not available
            order[item_name] = {'quantity': new_quantity, 'price': item_price}
            print(f"Added {item_name} to the order with {new_quantity} units.")
        else:
            print(f"Cannot add {item_name} to the order without a valid price and quantity.")
    return order

"""Example usage:
order = {'apple': {'quantity': 3, 'price': 1.0}, 'banana': {'quantity': 2, 'price': 0.5}}
update_order(order, 'apple', 5)
update_order(order, 'banana', 0)
update_order(order, 'cherry', 10, 0.3)
print(order)  # Should show the updated order"""